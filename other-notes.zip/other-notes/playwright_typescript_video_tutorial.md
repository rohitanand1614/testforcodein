---
print_background: true
---

<style>
@page {
  background-color: #121212;
  margin: 0;
}
body {
  background-color: #121212;
  color: #ffffff;
  margin: 0;
}
</style>

# Complete Playwright with TypeScript Guide

> A comprehensive reference covering Playwright testing framework with TypeScript in VS Code

---

## Table of Contents

1. [Getting Started](#getting-started)
2. [Project Structure](#project-structure)
3. [Configuration](#configuration)
4. [VS Code Extension](#vs-code-extension)
5. [Writing Tests](#writing-tests)
6. [Locators](#locators)
7. [Assertions](#assertions)
8. [Test Organization](#test-organization)
9. [Running Tests](#running-tests)
10. [Debugging & Reporting](#debugging--reporting)
11. [Advanced Features](#advanced-features)
12. [Best Practices](#best-practices)

---

## Getting Started

### Installation & Setup

```bash
# Install Playwright
npm init playwright@latest

# Install with specific options
npm init playwright@latest -- --quiet --browser=chromium --browser=firefox
```

### Key Dependencies

```json
{
  "devDependencies": {
    "@playwright/test": "^1.x.x",
    "@types/node": "^20.x.x",
    "typescript": "^5.x.x"
  }
}
```

**Dependency Roles:**
- `@playwright/test` - Core testing framework with assertions and fixtures
- `@types/node` - TypeScript type definitions for Node.js APIs
- `typescript` - TypeScript compiler for type checking

---

## Project Structure

### Default Folders

#### `playwright-report/`
- **Purpose**: Contains HTML test execution reports
- **Generated**: After each test run
- **Contents**: Interactive HTML report with test results, screenshots, videos
- **Access**: Open `index.html` in browser or run `npx playwright show-report`

#### `test-results/`
- **Purpose**: Stores test artifacts (screenshots, videos, traces)
- **Structure**: Organized by test name and retry attempts
- **Cleanup**: Automatically cleared on new test runs
- **Usage**: Referenced in debugging failed tests

#### `.last-run.json`
- **Purpose**: Tracks failed tests from last run
- **Usage**: Enables re-running only failed tests
- **Command**: `npx playwright test --last-failed`
- **Format**: JSON file with test paths and statuses

---

## Configuration

### `playwright.config.ts`

The central configuration file controlling all Playwright behavior.

```typescript
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  // Test directory
  testDir: './tests',
  
  // Parallel execution
  fullyParallel: true,
  workers: process.env.CI ? 1 : undefined,
  
  // Retry configuration
  retries: process.env.CI ? 2 : 0,
  
  // Reporter configuration
  reporter: [
    ['html'],
    ['json', { outputFile: 'test-results.json' }],
    ['junit', { outputFile: 'results.xml' }],
    ['list']
  ],
  
  // Global timeout settings
  timeout: 30000, // 30 seconds per test
  expect: {
    timeout: 5000 // 5 seconds for assertions
  },
  ```

  ```typescript
  // Browser launch options
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    headless: true,
    viewport: { width: 1280, height: 720 },
    
    // Browser channel
    channel: 'chrome', // 'chrome', 'msedge', 'chrome-beta'
  },
  
  // Projects for multiple browsers
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'mobile-chrome',
      use: { ...devices['Pixel 5'] },
    },
  ],
  ```

  ```typescript
  // Web server
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

### Browser Channel Options

```typescript
// Use different browser channels
use: {
  channel: 'chrome',        // Stable Chrome
  channel: 'chrome-beta',   // Beta Chrome
  channel: 'chrome-dev',    // Dev Chrome
  channel: 'msedge',        // Microsoft Edge
  channel: 'msedge-beta',   // Edge Beta
}
```

**Purpose**: Test against different browser versions without separate installations.

### Headed vs Headless Mode

```typescript
// In playwright.config.ts
use: {
  headless: false, // Show browser (headed mode)
  headless: true,  // Hide browser (headless mode)
}
```

```bash
# Command line override
npx playwright test --headed
npx playwright test --headless
```

### Viewport and Window Size

```typescript
// Set viewport size
use: {
  viewport: { width: 1920, height: 1080 },
}

// Maximize window in test
test('with maximized window', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 });
  
  // Or use null to maximize
  await page.setViewportSize({ width: 0, height: 0 });
});
```

---

## VS Code Extension

### Installation
Search "Playwright Test for VSCode" in VS Code Extensions

### Key Features

#### 1. **Test Explorer Panel**
- View all tests in sidebar
- Run individual tests with play button
- See test status (passed/failed/skipped)
- Quick navigation to test files
![](2025-11-03-14-45-22.png)
#### 2. **Project Filter**
Projects defined in `playwright.config.ts` appear in VS Code extension:
- Dropdown to select specific projects (chromium, firefox, webkit)
- Run tests on selected browsers only
- Multi-project selection support
![](2025-11-03-14-46-35.png)
![](2025-11-03-14-46-05.png)
#### 3. **Test Options in Tools**
- **Show Browser**: Run tests in headed mode
- **Show Trace Viewer**: Open trace for debugging
- **Pick Locator**: Interactive locator picker
- **Record New Test**: Launch codegen
- **Record at Cursor**: Start recording from cursor position
![](2025-11-03-14-47-36.png)
#### 4. **Watch Mode**
```typescript
// Enable in VS Code extension settings
"playwright.watchMode": true
```
- Automatically re-runs tests on file save
- Useful for TDD workflow
- Toggle from extension toolbar
![](2025-11-03-14-49-46.png)
![](2025-11-03-14-50-09.png)
#### 5. **Filter in VS Code**
Use the search/filter box to find tests:
- By test name: `"login test"`
- By file: `"auth.spec.ts"`
- By tag: `"@smoke"`
- By status: Failed/Passed tests
![](2025-11-03-14-50-51.png)
---

## Writing Tests

### Basic Test Structure

```typescript
import { test, expect } from '@playwright/test';

test('basic test example', async ({ page }) => {
  // Navigate
  await page.goto('https://example.com');
  
  // Interact
  await page.click('button');
  
  // Assert
  await expect(page.locator('h1')).toHaveText('Success');
});
```

### Test Method Components

```typescript
test(
  'test name',           // Test description
  async ({ page }) => {  // Async function with fixtures
    // Test body
  }
);
```

**Arguments:**
- `test name` (string): Descriptive test name for reporting
- `async function`: Test implementation (must be async)
- `{ page }`: Fixtures (page, browser, context, request)

### Test Steps

```typescript
test('test with steps', async ({ page }) => {
  await test.step('Navigate to login page', async () => {
    await page.goto('/login');
  });
  
  await test.step('Enter credentials', async () => {
    await page.fill('#username', 'user@example.com');
    await page.fill('#password', 'password123');
  });
  
  await test.step('Submit login form', async () => {
    await page.click('button[type="submit"]');
  });
  
  await test.step('Verify dashboard', async () => {
    await expect(page).toHaveURL('/dashboard');
  });
});
```

**Benefits:**
- Better reporting with step-by-step breakdown
- Easier debugging (see which step failed)
- `describe` in step names improves report hierarchy

### Page Fixture

```typescript
test('understanding page fixture', async ({ page }) => {
  // page is the main fixture for browser interaction
  // - Automatically created and cleaned up
  // - Isolated browser context
  // - Full browser automation API
  
  await page.goto('https://example.com');
  await page.locator('button').click();
});
```

**What is `page`?**
- Represents a single browser tab/page
- Automatically managed (created/destroyed per test)
- Includes navigation, interaction, and assertion methods
- Isolated from other tests (separate browser context)

---

## Locators

### Overview

Locators are Playwright's way to find elements on a page. They are **auto-waiting** and **strict** by default.

### Locator Types & Priority

#### 1. **`getByRole()` - MOST PREFERRED** ⭐

```typescript
// Best for accessibility and reliability
await page.getByRole('button', { name: 'Submit' }).click();
await page.getByRole('link', { name: 'Sign up' }).click();
await page.getByRole('textbox', { name: 'Email' }).fill('test@example.com');
await page.getByRole('checkbox', { name: 'I agree' }).check();
```

**Pros:**
- Accessibility-focused (tests real user experience)
- Resistant to DOM changes
- Self-documenting
- Best practice recommended by Playwright team

**Cons:**
- Requires proper ARIA roles in HTML
- May not work with poorly structured pages

**Common Roles:**
- `button`, `link`, `textbox`, `checkbox`, `radio`
- `heading`, `listitem`, `table`, `row`, `cell`
- `img`, `banner`, `navigation`, `main`, `form`

#### 2. **`getByLabel()` - Form Elements**

```typescript
await page.getByLabel('Email address').fill('user@test.com');
await page.getByLabel('Password').fill('secret');
await page.getByLabel('Remember me').check();
```

**Pros:**
- Perfect for forms with proper labels
- Semantic and readable

**Cons:**
- Requires `<label>` elements or `aria-label`

#### 3. **`getByPlaceholder()` - Input Hints**

```typescript
await page.getByPlaceholder('Search...').fill('playwright');
await page.getByPlaceholder('Enter your email').fill('test@example.com');
```

**Pros:**
- Quick for inputs with placeholders
- Human-readable

**Cons:**
- Placeholders can change frequently
- Not ideal for accessibility

#### 4. **`getByText()` - Visible Text**

```typescript
await page.getByText('Welcome back!').click();
await page.getByText('Sign up', { exact: true }).click();

// Partial match
await page.getByText(/submit/i).click();
```

**Pros:**
- Intuitive and readable
- Good for links and buttons with text

**Cons:**
- Breaks if text changes
- Language-dependent

#### 5. **`getByAltText()` - Images**

```typescript
await page.getByAltText('Company logo').click();
await page.getByAltText(/profile picture/i).isVisible();
```

**Use case:** Finding images by their `alt` attribute

#### 6. **`getByTitle()` - Tooltips**

```typescript
await page.getByTitle('Close window').click();
await page.getByTitle(/help/i).hover();
```

**Use case:** Elements with `title` attribute

#### 7. **`getByTestId()` - Test-Specific**

```typescript
await page.getByTestId('submit-button').click();
await page.getByTestId('user-profile-modal').isVisible();
```

**Pros:**
- Stable and dedicated for testing
- Not affected by UI changes

**Cons:**
- Requires adding `data-testid` attributes
- Not semantic

**Configuration:**
```typescript
// playwright.config.ts
use: {
  testIdAttribute: 'data-testid', // or 'data-test', 'data-qa'
}
```
![](2025-11-03-14-52-35.png)
#### 8. **`locator()` - CSS/XPath (Fallback)**

```typescript
// CSS selectors
await page.locator('#submit-btn').click();
await page.locator('.modal-header').isVisible();
await page.locator('button[type="submit"]').click();

// XPath
await page.locator('xpath=//button[text()="Submit"]').click();
```

**Use case:**
- When semantic locators aren't available
- Complex DOM traversal
- Legacy code

**Cons:**
- Fragile (breaks with DOM changes)
- Less readable
- Not accessibility-focused

### Locator Combination & Filtering

#### Chaining Locators

```typescript
// Find button inside a specific dialog
await page.locator('dialog').getByRole('button', { name: 'Close' }).click();

// Find text within a container
await page.locator('.user-profile').getByText('John Doe').isVisible();
```

#### Using `.first()`, `.last()`, `.nth()`

```typescript
// First match
await page.getByRole('listitem').first().click();

// Last match
await page.getByRole('listitem').last().click();

// Nth match (0-indexed)
await page.getByRole('listitem').nth(2).click(); // 3rd item

// Count items
const count = await page.getByRole('listitem').count();
```

#### Filtering Locators

```typescript
// Filter by text
await page
  .getByRole('listitem')
  .filter({ hasText: 'Active' })
  .click();

// Filter by another locator
await page
  .getByRole('listitem')
  .filter({ has: page.getByRole('button', { name: 'Edit' }) })
  .click();

// Filter by visible only
await page
  .getByText('Submit')
  .filter({ hasNotText: 'Disabled' })
  .click();
```

#### Visible Text Filtering

```typescript
// Match only visible text (ignore hidden elements)
await page.locator('div', { hasText: /visible/i }).filter({
  has: page.locator(':visible')
}).click();

// Or using getByText with visible option
await page.getByText('Click me', { exact: true }).click();
```

### Pick and Paste Locator

**In VS Code Extension:**
1. Click "Pick Locator" button in Playwright toolbar
2. Browser opens and hover over elements
3. Click desired element
4. Locator code automatically copied to clipboard
5. Paste in your test file

```typescript
// Example of picked locator
await page.getByRole('button', { name: 'Sign in' }).click();
```
![](2025-11-03-14-55-37.png)
### Best Locator Strategy Workflow

```
1. Try getByRole() first ✓ (most resilient)
2. Try getByLabel() for forms
3. Try getByPlaceholder() or getByText()
4. Use getByTestId() if adding test attributes is possible
5. Use locator() with CSS/XPath as last resort
```
## 🧩 Fixing Failures with AI in VS Code Extension

Playwright's VS Code extension now supports **AI-assisted debugging** for failed tests.

### 🔧 How It Works
When a test fails:
1. Open the failed test in VS Code.
2. Click **"Fix using AI"** beside the failure trace.
3. The AI analyzes trace data and suggests fixes to the test code.
4. Apply and re-run the test to verify the solution.
![](2025-11-03-15-07-13.png)
### 💡 Benefits
- Fixes common locator or timing issues automatically.
- Integrates tightly with VS Code test explorer.
- Great for quick iteration during development.

---
## 🧠 Fixing Failures via Playwright Report (Copy Prompt)

Playwright's HTML report includes **AI-assisted debugging support** through prompt sharing.

### 🪄 How To Use
1. Open the Playwright HTML report.
2. Click **"View Trace"** on a failed test.
3. Use **"Copy Prompt"** to copy a ready-to-use AI debugging query.
4. Paste it into your preferred AI assistant to get analysis or code suggestions.

### 💡 Benefits
- Enables AI debugging outside VS Code.
- Ideal for CI/CD review or shared test environments.
- Provides trace-aware context for smarter AI recommendations.
![](2025-11-03-15-07-41.png)
## Assertions

Playwright uses `expect()` for assertions with automatic waiting.

### Basic Assertions

```typescript
import { expect } from '@playwright/test';

test('assertion examples', async ({ page }) => {
  const locator = page.locator('h1');
  
  // Visibility
  await expect(locator).toBeVisible();
  await expect(locator).toBeHidden();
  
  // Enabled/Disabled
  await expect(page.locator('button')).toBeEnabled();
  await expect(page.locator('button')).toBeDisabled();
  ```
  ```typescript
  // Checked state
  await expect(page.locator('checkbox')).toBeChecked();
  await expect(page.locator('checkbox')).not.toBeChecked();
  
  // Focus
  await expect(page.locator('input')).toBeFocused();
  
  // Editable
  await expect(page.locator('input')).toBeEditable();
  
  // Empty
  await expect(page.locator('input')).toBeEmpty();
});
```

### `toBe` Assertions

```typescript
// toBe (strict equality)
expect(value).toBe(5);
expect(status).toBe('active');
expect(isValid).toBe(true);

// toBeTruthy / toBeFalsy
expect(value).toBeTruthy();
expect(value).toBeFalsy();

// toBeDefined / toBeUndefined
expect(user).toBeDefined();
expect(deletedUser).toBeUndefined();
  ```
  
  ```typescript
// toBeNull
expect(emptyValue).toBeNull();

// toBeNaN
expect(parseFloat('invalid')).toBeNaN();

// toBeGreaterThan / toBeLessThan
expect(score).toBeGreaterThan(100);
expect(score).toBeLessThan(200);
expect(score).toBeGreaterThanOrEqual(100);
expect(score).toBeLessThanOrEqual(200);

// toBeCloseTo (floating point)
expect(0.1 + 0.2).toBeCloseTo(0.3);
```

### `toHave` Assertions

```typescript
test('toHave assertions', async ({ page }) => {
  // toHaveText (exact match)
  await expect(page.locator('h1')).toHaveText('Welcome');
  
  // toContainText (partial match)
  await expect(page.locator('p')).toContainText('success');
  
  // toHaveValue (input value)
  await expect(page.locator('input')).toHaveValue('john@example.com');
  
  // toHaveAttribute
  await expect(page.locator('a')).toHaveAttribute('href', '/login');
  await expect(page.locator('img')).toHaveAttribute('alt', /logo/i);
  ```
  ```typescript
  
  // toHaveClass
  await expect(page.locator('button')).toHaveClass('btn-primary');
  await expect(page.locator('button')).toHaveClass(/btn-/);
  
  // toHaveCount
  await expect(page.locator('li')).toHaveCount(5);
  
  // toHaveCSS
  await expect(page.locator('button')).toHaveCSS('color', 'rgb(255, 0, 0)');
  
  // toHaveId
  await expect(page.locator('div')).toHaveId('main-content');
  ```

  ```typescript  
  // toHaveURL
  await expect(page).toHaveURL('https://example.com/dashboard');
  await expect(page).toHaveURL(/dashboard/);
  
  // toHaveTitle
  await expect(page).toHaveTitle('Dashboard | My App');
  await expect(page).toHaveTitle(/Dashboard/);
  
  // toHaveScreenshot
  await expect(page).toHaveScreenshot('homepage.png');
   ```
  ```typescript 
  // toHaveAccessibleName
  await expect(page.getByRole('button')).toHaveAccessibleName('Submit form');
  
  // toHaveAccessibleDescription
  await expect(page.locator('input')).toHaveAccessibleDescription('Enter your email');
  
  // toHaveRole
  await expect(page.locator('button')).toHaveRole('button');
});
```

### Array & Object Assertions

```typescript
// Array assertions
expect(array).toHaveLength(3);
expect(array).toContain('item');
expect(array).toContainEqual({ id: 1, name: 'Test' });

// Object assertions
expect(object).toEqual({ key: 'value' }); // Deep equality
expect(object).toMatchObject({ key: 'value' }); // Partial match
expect(object).toHaveProperty('key', 'value');

// String assertions
expect(text).toMatch(/pattern/);
expect(text).toMatch('substring');
```

### Soft Assertions

Soft assertions don't stop test execution on failure - all assertions run and failures are reported at the end.

```typescript
import { test, expect } from '@playwright/test';

test('soft assertions example', async ({ page }) => {
  await page.goto('https://example.com');
  
  // Regular assertion (stops on failure)
  await expect(page).toHaveTitle('Example');
  ```
  ```typescript  
  // Soft assertions (continues on failure)
  await expect.soft(page.locator('h1')).toHaveText('Welcome');
  await expect.soft(page.locator('.price')).toContainText('$99');
  await expect.soft(page.locator('button')).toBeVisible();
  
  // Test continues even if soft assertions fail
  await page.click('button');
  
  // All soft assertion failures reported at end
});
```

**Use cases:**
- Checking multiple independent conditions
- Validation tests where you want to see all failures
- Visual regression tests

### Accessibility Assertions

```typescript
test('accessibility assertions', async ({ page }) => {
  await page.goto('https://example.com');
  
  // Check accessible name
  await expect(page.getByRole('button')).toHaveAccessibleName('Submit');
  
  // Check accessible description
  await expect(page.locator('input')).toHaveAccessibleDescription(
    'Enter your email address'
  );
  ```
  ```typescript  
  // Check role
  await expect(page.locator('nav')).toHaveRole('navigation');
  
  // Check ARIA attributes
  await expect(page.locator('[role="dialog"]')).toHaveAttribute(
    'aria-modal',
    'true'
  );
  
  // Check keyboard navigation
  await page.keyboard.press('Tab');
  await expect(page.locator('button')).toBeFocused();
});
```

---

## Test Organization

### Test Grouping with `describe`

```typescript
import { test, expect } from '@playwright/test';

test.describe('User Authentication', () => {
  test('should login with valid credentials', async ({ page }) => {
    // Test implementation
  });
  
  test('should show error with invalid credentials', async ({ page }) => {
    // Test implementation
  });
  
  test.describe('Password Reset', () => {
    test('should send reset email', async ({ page }) => {
      // Nested group
    });
  });
});
```

**Benefits:**
- Logical test organization
- Better reporting hierarchy
- Shared setup/teardown via hooks
- Improved step reporting when used with `test.step()`
![](2025-11-03-15-03-37.png)

### Tags

```typescript
// Single tag
test('login test @smoke', async ({ page }) => {
  // Test implementation
});

// Multiple tags
test('checkout flow @smoke @critical', async ({ page }) => {
  // Test implementation
});

// Using describe with tags
test.describe('API Tests @api', () => {
  test('create user', async ({ request }) => {
    // Test implementation
  });
});
```

**Running tagged tests:**
```bash
# Run tests with specific tag
npx playwright test --grep @smoke

# Run tests without tag
npx playwright test --grep-invert @skip

# Multiple tags (OR)
npx playwright test --grep "@smoke|@critical"

# Multiple tags (AND) - requires both
npx playwright test --grep "(?=.*@smoke)(?=.*@critical)"
```

### Test Hooks

```typescript
test.describe('Test Suite', () => {
  // Runs once before all tests in describe
  test.beforeAll(async ({ browser }) => {
    // Setup database, create test user, etc.
  });
  
  // Runs before each test
  test.beforeEach(async ({ page }) => {
    await page.goto('https://example.com');
  });
  ```
  ```typescript 
  // Runs after each test
  test.afterEach(async ({ page }) => {
    // Cleanup, screenshot on failure, etc.
  });
  
  // Runs once after all tests
  test.afterAll(async () => {
    // Cleanup resources
  });
  ```
  ```typescript  
  test('test 1', async ({ page }) => {
    // Test implementation
  });
  
  test('test 2', async ({ page }) => {
    // Test implementation
  });
});
```

### Skip and Only

```typescript
// Skip test
test.skip('not ready yet', async ({ page }) => {
  // This test won't run
});

// Conditional skip
test('mobile test', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'This test is only for mobile');
  // Test continues only on mobile
});
  ```
  ```typescript
// Skip in hook
test.beforeEach(async ({ browserName }) => {
  test.skip(browserName === 'webkit', 'Not supported on Safari');
});

// Only - run this test exclusively
test.only('run only this', async ({ page }) => {
  // Only this test runs in the file
});
  ```
  ```typescript
// Skip entire describe block
test.describe.skip('Feature not ready', () => {
  test('test 1', async ({ page }) => {});
  test('test 2', async ({ page }) => {});
});
```

### Test.fail() and test.fixme()

```typescript
// test.fail() - Expect test to fail (inverts result)
test('known bug', async ({ page }) => {
  test.fail(); // If test fails, it's marked as expected
  await page.goto('https://broken-feature.com');
  // Assertions that currently fail
});
  ```
  ```typescript
// Conditional fail
test('browser-specific bug', async ({ page, browserName }) => {
  test.fail(browserName === 'webkit', 'Bug #123 - fails on Safari');
  // Test implementation
});
  ```
  ```typescript
// test.fixme() - Mark test as fixme (always skips)
test.fixme('need to fix this', async ({ page }) => {
  // Test won't run, marked as fixme in report
});
```

### Annotations

```typescript
test('annotated test', async ({ page }) => {
  // Add custom annotations to test
  test.info().annotations.push(
    { type: 'issue', description: 'https://github.com/issues/123' },
    { type: 'author', description: 'john.doe@example.com' }
  );
  
  // Test implementation
});
  ```
  ```typescript
// Using slow annotation
test('slow test', async ({ page }) => {
  test.slow(); // Triples timeout for this test
  // Long-running operations
});

// Category annotation
test('api test', async ({ request }) => {
  test.info().annotations.push({ type: 'category', description: 'api' });
  // Test implementation
});
```

**Annotations appear in:**
- HTML report
- JSON report
- Test metadata

---

## Running Tests

### Command Line Options

```bash
# Run all tests
npx playwright test

# Run specific file
npx playwright test tests/login.spec.ts

# Run tests in folder
npx playwright test tests/auth/
  ```
  ```bash
# Run specific test by line number
npx playwright test tests/login.spec.ts:42

# Run tests matching pattern
npx playwright test login

# Run with specific browser
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit
  ```
  ```bash
# Run specific project from config
npx playwright test --project="Mobile Chrome"

# Multiple projects
npx playwright test --project=chromium --project=firefox

# Headed mode
npx playwright test --headed
  ```
  ```bash
# Debug mode
npx playwright test --debug

# UI mode
npx playwright test --ui

# Run tagged tests
npx playwright test --grep @smoke
npx playwright test --grep-invert @slow
  ```
  ```bash
# Run with workers (parallel)
npx playwright test --workers=4
npx playwright test --workers=1  # Serial execution

# Run specific test by title
npx playwright test -g "should login"

# Update snapshots
npx playwright test --update-snapshots
  ```
  ```bash
# Run last failed tests
npx playwright test --last-failed

# Run only changed tests
npx playwright test --only-changed

# Generate report
npx playwright show-report

# Run with trace
npx playwright test --trace on
```

### Running from VS Code Extension

1. **Test Explorer**:
   - Click play button next to test
   - Right-click → Run Test / Debug Test

2. **File Level**:
   - Play button at top of spec file
   - Runs all tests in file

3. **Options**:
   - Select project (browser) from dropdown
   - Toggle "Show browser" for headed mode
   - Enable "Show trace viewer" for debugging

### Parallel Execution

#### In Config File

```typescript
// playwright.config.ts
export default defineConfig({
  fullyParallel: true,  // Run tests in parallel within file
  workers: 4,           // Number of parallel workers
  
  // Or conditional
  workers: process.env.CI ? 1 : undefined, // Serial in CI
});
```

#### Command Line

```bash
# Run with 4 workers
npx playwright test --workers=4

# Run serially (one at a time)
npx playwright test --workers=1

# Use 50% of CPU cores
npx playwright test --workers=50%
```

### Running Tests Multiple Times

```bash
# Repeat tests (for flakiness detection)
npx playwright test --repeat-each=3

# In CI configuration
npx playwright test --repeat-each=10 --workers=1

# Local testing for stability
npx playwright test --repeat-each=5 login.spec.ts
```

**Use cases:**
- Detect flaky tests
- Stress testing
- Performance benchmarking

### Test Selection with testConfig.json

Create `testConfig.json`:
```json
{
  "testDir": "./tests",
  "testMatch": "**/*.spec.ts",
  "testIgnore": [
    "**/node_modules/**",
    "**/dist/**",
    "**/*.skip.spec.ts"
  ]
}
```

In `playwright.config.ts`:
```typescript
export default defineConfig({
  testDir: './tests',
  testMatch: '*.spec.ts',
  testIgnore: '*.skip.spec.ts',
});
```

---

## Debugging & Reporting

### Debug Mode

```bash
# Run in debug mode (opens inspector)
npx playwright test --debug

# Debug specific test
npx playwright test login.spec.ts --debug

# Debug from specific line
npx playwright test login.spec.ts:42 --debug
```

**Debug features:**
- Step through test execution
- Inspect locators
- View DOM snapshots
- Console logs
- Network activity

### UI Mode

```bash
# Open UI mode
npx playwright test --ui
```

**UI Mode features:**
- Visual test runner
- Live test execution watch
- Time travel debugging
- DOM snapshots at each step
- Network and console logs
- Filter and search tests
- Watch mode for auto-rerun

### Trace Viewer

```typescript
// Enable traces in config
export default defineConfig({
  use: {
    trace: 'on-first-retry',     // Trace on retry
    // or
    trace: 'on',                 // Always trace
    trace: 'off',                // Never trace
    trace: 'retain-on-failure',  // Keep only failed
  },
});
```

```bash
# View trace from command line
npx playwright show-trace trace.zip

# Traces saved in test-results folder
```

**Trace Viewer Features:**
- **Timeline**: Visual timeline of all actions
- **Snapshots**: Before/after DOM snapshots
- **Network**: All network requests
- **Console**: Console logs
- **Source**: Test source code
- **Call**: Action call details
- **Metadata**: Test metadata and errors

**Navigation:**
- Click on timeline to see snapshots
- Hover over actions for details
- Use arrow keys to move through actions
- Filter by action type

### Screenshots

#### Screenshot Options

```typescript
// In config
export default defineConfig({
  use: {
    screenshot: 'off',              // No screenshots
    screenshot: 'on',               // Always capture
    screenshot: 'only-on-failure',  // Only when test fails
  },
});
```

```typescript
// In test - full page screenshot
await page.screenshot({ path: 'screenshot.png' });

// Element screenshot
await page.locator('.header').screenshot({ path: 'header.png' });

// Full page (scrolls if needed)
await page.screenshot({ 
  path: 'fullpage.png', 
  fullPage: true 
});
  ```
  ```typescript
// Options
await page.screenshot({
  path: 'screenshot.png',
  fullPage: true,
  clip: { x: 0, y: 0, width: 100, height: 100 }, // Crop area
  omitBackground: true,  // Transparent background
  type: 'jpeg',          // 'png' or 'jpeg'
  quality: 80,           // JPEG quality (0-100)
});
```

### Screenshot Styling

Inject custom CSS to style elements before taking screenshots:

```typescript
test('screenshot with custom styling', async ({ page }) => {
  await page.goto('https://example.com');
  
  // In the page - hide elements
  await page.addStyleTag({
    content: `
      [data-screenshot="transparent"] {
        display: none !important;
      }
    `
  });
  ```
  ```typescript
  // Or add to canvas element
  await page.evaluate(() => {
    const canvas = document.querySelector('canvas');
    if (canvas) canvas.setAttribute('data-screenshot', 'transparent');
  });
  
  await page.screenshot({ path: 'styled.png' });
});
```

#### In playwright.config.ts

```typescript
export default defineConfig({
  use: {
    screenshot: 'only-on-failure',
    
    // Inject CSS for all screenshots
    styleTagPath: './screenshot.css',
  },
});
```

#### screenshot.css file

```css
/* Hide specific elements in screenshots */
[data-screenshot="transparent"] {
  visibility: hidden !important;
}

/* Remove sensitive data */
[data-screenshot="removed"] {
  display: none !important;
}

/* Style elements differently */
[data-screenshot="normalize"] {
  border-radius: 0 !important;
}
```

Or configure inline in test:

```typescript
await page.addStyleTag({
  content: `
    [data-screenshot="transparent"] {
      display: none !important;
    }
    [data-screenshot="removed"] {
      visibility: hidden !important;
    }
  `
});
```

### Reports

```typescript
// In config
export default defineConfig